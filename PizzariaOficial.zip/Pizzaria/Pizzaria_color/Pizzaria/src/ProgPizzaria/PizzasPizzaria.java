package ProgPizzaria;

/**
 *
 * @author Jayana
 */
public class PizzasPizzaria {

    protected String NomeSabor, Borda, Base;
    protected String Ingrediente1, Ingrediente2, Ingrediente3;

    public String getNomeSabor() {
        return NomeSabor;
    }

    public void setNomeSabor(String NomeSabor) {
        this.NomeSabor = NomeSabor;
    }

    public String getIngrediente1() {
        return Ingrediente1;
    }

    public void setIngrediente1(String Ingrediente1) {
        this.Ingrediente1 = Ingrediente1;
    }

    public String getIngrediente2() {
        return Ingrediente2;
    }

    public void setIngrediente2(String Ingrediente2) {
        this.Ingrediente2 = Ingrediente2;
    }

    public String getIngrediente3() {
        return Ingrediente3;
    }

    public void setIngrediente3(String Ingrediente3) {
        this.Ingrediente3 = Ingrediente3;
    }

    public String getBorda() {
        return Borda;
    }

    public void setBorda(String Borda) {
        this.Borda = Borda;
    }

    public String getBase() {
        return Base;
    }

    public void setBase(String Base) {
        this.Base = Base;
    }

}
