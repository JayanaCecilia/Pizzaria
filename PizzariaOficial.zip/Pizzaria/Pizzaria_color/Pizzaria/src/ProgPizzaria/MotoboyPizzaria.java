package ProgPizzaria;

/**
 *
 * @author Jayana
 */
public class MotoboyPizzaria {

    protected String Nome, CPF, Tel, Email, CNH, ValidadeCNH, Moto, Bicicleta, Veiculo;

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public String getTel() {
        return Tel;
    }

    public void setTel(String Tel) {
        this.Tel = Tel;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getCNH() {
        return CNH;
    }

    public void setCNH(String CNH) {
        this.CNH = CNH;
    }

    public String getValidadeCNH() {
        return ValidadeCNH;
    }

    public void setValidadeCNH(String ValidadeCNH) {
        this.ValidadeCNH = ValidadeCNH;
    }

    public String getMoto() {
        return Moto;
    }

    public void setMoto(String Moto) {
        this.Moto = Moto;
    }

    public String getBicicleta() {
        return Bicicleta;
    }

    public void setBicicleta(String Bicicleta) {
        this.Bicicleta = Bicicleta;
    }

    public String getVeiculo() {
        return Veiculo;
    }

    public void setVeiculo(String Veiculo) {
        this.Veiculo = Veiculo;
    }

}
